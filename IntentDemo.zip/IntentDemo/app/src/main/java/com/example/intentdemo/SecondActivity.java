package com.example.intentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tvFirstActivityData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvFirstActivityData = findViewById(R.id.tvFirstActivityData);

        tvFirstActivityData.setText(
                getIntent().getIntExtra("id", 0) + " 1" +
                        getIntent().getStringExtra("name") + "1 " +
                        getIntent().getDoubleExtra("price", 0.0) + "1"
        );


    }

    public void onResult(View view) {
        int a = getIntent().getIntExtra("valueA", 0);
        int total = a + 50;
        Intent i = new Intent();
        i.putExtra("total", total + "");
        setResult(RESULT_OK, i);
        finish();
    }
}